
RunRAxML<-function(user.name, token, DE.file.name="", DE.file.path="", data="nucleotides", model=match.arg(model, choices=c("GTRCAT", "GTRGAMMA")), output.file.name="output.final") {
	# -s sequenceFileName (DE.file.name)
	# -n outputFileName (output.file.name)
	# data restricted to nucleotides for now, but could be expanded to use AA as well.
	# -m substitutionModel (model); full nucleotides options include = c("GTRCAT", "GTRGAMMA", "GTRCAT_GAMMA", "GTRGAMMAI", "GTRCAT_GAMMAI"); full aa include = c()
	# I am starting to rething using match.arg here since there are SO many choices.  For now, lets just leave it at these two, but we might think about making the user go to the help file for all the options.  
	# for now, we are only going to call default settings (this is the "-f d" part of the call)
	# 'raxmlHPC -f d -m model -s DE.file.name -n output.file.name'  <- paste()

}
